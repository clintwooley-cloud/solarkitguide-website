# SolarKitGuide BigVu Weekend Shoot Pack 01

Purpose: quick scripts Clint can load into BigVu and record with an iPad teleprompter.

Format:
- Short-form vertical videos: 30–60 seconds
- Style: beginner-friendly, practical, no hype
- CTA: send viewers to SolarKitGuide.com, the calculator, or specific guides/product reviews
- Disclosure when mentioning affiliate products: “Some links may be affiliate links, which means the site may earn a commission at no extra cost to you.”

Recommended recording style:
- Record each script twice: one calm/educational, one slightly more energetic.
- Keep eye contact with the teleprompter.
- Start with the hook immediately — no “Hey guys.”
- Leave 1 second of silence before and after each take for easier editing.
